create
    definer = rdsadmin@localhost procedure enable_rewriter()
BEGIN
  DECLARE sql_logging BOOLEAN;
  DECLARE v_called_by_user VARCHAR(50);
  DECLARE v_mysql_version VARCHAR(20);
  SELECT user() into v_called_by_user;
  SELECT version() into v_mysql_version;
  select @@sql_log_bin into sql_logging;
  CREATE DATABASE IF NOT EXISTS query_rewrite;
  CREATE TABLE IF NOT EXISTS query_rewrite.rewrite_rules (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    pattern VARCHAR(10000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    pattern_database VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_bin,
    replacement VARCHAR(10000) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    enabled ENUM('YES', 'NO') CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
      DEFAULT 'YES',
    message VARCHAR(1000) CHARACTER SET utf8 COLLATE utf8_bin,
    pattern_digest VARCHAR(32),
    normalized_pattern VARCHAR(100)
  ) DEFAULT CHARSET = utf8 ENGINE = INNODB;
  INSTALL PLUGIN rewriter SONAME 'rewriter.so';
  set @@sql_log_bin=off;
  INSERT into mysql.rds_history(called_by_user, action, mysql_version) values (v_called_by_user,'Plugin Rewriter Enabled', v_mysql_version);
  commit;
  SET @@sql_log_bin=sql_logging;
END;

